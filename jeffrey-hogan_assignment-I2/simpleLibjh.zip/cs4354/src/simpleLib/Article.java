package simpleLib;

public class Article extends LibraryDocument {

}
