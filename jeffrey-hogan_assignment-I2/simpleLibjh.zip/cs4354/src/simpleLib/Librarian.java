package simpleLib;

public class Librarian extends LibraryUser {

	public Librarian(String username, String password) {
		super(username, password);
		// TODO Auto-generated constructor stub
	}

	public Librarian(String username, String password, String id) {
		super(username, password);
	}





}
