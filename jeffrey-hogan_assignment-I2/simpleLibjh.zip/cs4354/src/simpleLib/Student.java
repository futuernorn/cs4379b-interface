package simpleLib;

public class Student extends LibraryUser {

	public Student(String username, String password, String id) {
		super(username, password);
		// TODO Auto-generated constructor stub
	}



}
