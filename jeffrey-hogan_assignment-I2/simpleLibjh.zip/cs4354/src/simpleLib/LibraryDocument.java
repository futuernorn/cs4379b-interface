package simpleLib;

import java.util.Date;

public abstract class LibraryDocument  implements java.io.Serializable {
	String publisher;
	String title;
	Date publishDate;
	

}
