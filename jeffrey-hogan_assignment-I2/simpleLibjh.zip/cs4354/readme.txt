Program can be run on Linux with the following command:
 java -Dfile.encoding=UTF-8 -classpath /home/jeffrey/workspace/cs4354/bin simpleLib.Driver
